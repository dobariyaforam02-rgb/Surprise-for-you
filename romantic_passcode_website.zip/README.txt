# Romantic Passcode Website

## Passcode
1102

## Files
- index.html — website
- style.css — design
- script.js — working keypad/passcode
- couple-photo.jpeg — uploaded photo

## How to use
Keep all four files in the same folder and open `index.html` in a browser.

The keypad is made from real HTML buttons and the passcode is handled by JavaScript.
